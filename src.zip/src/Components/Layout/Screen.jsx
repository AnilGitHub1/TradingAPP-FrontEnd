import React from "react";

export default function Screen() {
  return <div className=".container-fluid screenActive"></div>;
}
