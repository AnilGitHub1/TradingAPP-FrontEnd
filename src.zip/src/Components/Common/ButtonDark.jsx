import React from "react";

const ButtonDark = (props) => {
  return <div className="buttonDark">{props.text}</div>;
};

export default ButtonDark;
