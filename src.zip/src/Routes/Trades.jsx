import React from "react";
import TradesTable from "../Features/Trades/TradesTable";

export default function Trades() {
  return (
    <div className="container">
      <TradesTable />
    </div>
  );
}
