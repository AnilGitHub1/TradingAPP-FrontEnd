import React from "react";

export default function Trade() {
  return <div>Trade page</div>;
}
